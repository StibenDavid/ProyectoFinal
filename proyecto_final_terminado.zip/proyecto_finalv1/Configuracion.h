#include "pines.h"
#include "MemoriaEEPROM.h"



void temp_High();
void temp_Low();
void Luz();
void Sonido();
