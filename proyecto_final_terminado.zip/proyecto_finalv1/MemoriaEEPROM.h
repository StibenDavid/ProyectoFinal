#include "pines.h"
#include <EEPROM.h>

void cargarValores();
void reiniciarValores();
