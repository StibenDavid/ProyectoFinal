#include "pines.h"

void seguridad();
