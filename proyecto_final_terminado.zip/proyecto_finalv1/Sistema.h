#include "pines.h"
void fotoresistor(void);
void temperatura(void);
